
import './App.css';
import Header from './Header';
import Left1 from './Left1';

function App() {
 return(
    <div className='main'>
     <Header/>
     <Left1/>
     
    </div>
 );
}

export default App;
